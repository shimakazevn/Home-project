]
[_tb_system_call storage=system/_EV_BADEND_houmon.ks]

[tb_start_tyrano_code]
[macro name="日高"]
[emb exp="f.familyname"]
[endmacro]

[macro name="舜"]
[emb exp="f.name"]
[endmacro]
[_tb_end_tyrano_code]

[tb_show_message_window  ]
*top

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_start_tyrano_code]
;画像OFF
[freeimage layer="2" time=0"]
[_tb_end_tyrano_code]

[call  storage="ui_onoff.ks"  target="*UI_off"  ]
[stopbgm  time="1000"  fadeout="true"  ]
[bg  time="2000"  method="crossfade"  storage="black.jpg"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="bell.mp3"  ]
[wait  time="1000"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
家のインターホンが鳴る。[p]
[舜]「……誰だ？」[p]
時計を見ると、早朝を少し過ぎた頃。[r]なんとなく胸騒ぎがして、玄関へ向かう足取りが重くなる。[p]
ためらいながらドアノブを握り、そっと回す。[p]
軋むような音とともに、玄関の扉が開かれた。[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="dooropen.mp3"  ]
[bg  time="2000"  method="crossfade"  storage="back_room_genkan.png"  ]
[playbgm  volume="50"  time="1000"  loop="true"  storage="kintyou.mp3"  ]
[tb_start_text mode=1 ]
そこには、スーツ姿の無骨な男が二人、無言で立っていた。[p]
男「あなた、[日高] [舜]さん？」[p]
一人の男が無機質な声で言った。[p]
男「警察だけど、違法アップロードの件で話を聞かせてくれる？…今、時間いいかな？」[p]
言葉の意味を理解する前に頭の中が真っ白になる。[r]男たちの顔も、声も、背景も、まるで靄の中に消えていく。[p]
何かを言おうとするが、喉が震えるだけで声が出ない。[r]淡々と投げかけられる質問の数々に、ただ頷くことしかできなかった。[p]
画面を見せられ、アカウントを確認されても、そこに現実味はなかった。[r]まるで夢の中にいるようだった。[p]
[舜]（ああ……全部、終わりだ……）[p]
その言葉だけが、かろうじて舜の中に残っていた。[p]
[_tb_end_text]

[bg  time="2000"  method="crossfade"  storage="black.jpg"  ]
[wait  time="1000"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[tb_start_text mode=1 ]
【BADEND_訪問者】[p]
[_tb_end_text]

[l  ]
[wait  time="3000"  ]
[tb_start_tyrano_code]
[iscript]
location.href="./index.html";
[endscript]
[_tb_end_tyrano_code]

[s  