n][preload  storage="./data/bgimage/back_massajiten3.png"  ]
[preload  storage="./data/bgimage/event/rinko_jyunaiEND.png"  ]
[preload  storage="./data/bgimage/black.jpg"  ]
[preload  storage="./data/bgimage/event_fin2.jpg"  ]
[preload  storage="./data/bgimage/event_fin.jpg"  ]
[retur