n][preload  storage="./data/bgimage/sin_nagi_nagiroom.png"  ]
[preload  storage="./data/bgimage/sora.jpg"  ]
[preload  storage="./data/bgimage/event/nagi2.png"  ]
[preload  storage="./data/bgimage/black.jpg"  ]
[retur