n][preload  storage="./data/bgimage/sora.jpg"  ]
[preload  storage="./data/bgimage/back_rihure_sekkyaku.png"  ]
[preload  storage="./data/bgimage/back_room_yoru0.png"  ]
[preload  storage="./data/bgimage/black.jpg"  ]
[retur