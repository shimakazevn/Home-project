n][preload  storage="./data/bgimage/back_dantimae_yoru.png"  ]
[preload  storage="./data/bgimage/back_room_yoru.png"  ]
[preload  storage="./data/bgimage/black.jpg"  ]
[preload  storage="./data/bgimage/back_nagi_genkan.png"  ]
[preload  storage="./data/bgimage/event/nagi3.png"  ]
[preload  storage="./data/bgimage/back_dantimae_hiru.png"  ]
[retur