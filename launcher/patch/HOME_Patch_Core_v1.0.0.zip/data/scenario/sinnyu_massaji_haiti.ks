]
[_tb_system_call storage=system/_sinnyu_massaji_haiti.ks]

[bg  time="0"  method="fadeIn"  storage="sin_rin_sejyutusitu.png"  ]
*top0

[tb_show_message_window  ]
[tb_start_text mode=1 ]
(どこに設置しようか。)[p]
[_tb_end_text]

[jump  storage="sinnyu_massaji_haiti.ks"  target="*top"  ]
*idou_top

[mask  time="700"  effect="slideInLeft"  color="0x000000"  ]
[cm  ]
[tb_start_tyrano_code]
;エフェクト消す
[free_layermode time="0"]
[freeimage layer="2" time="0"]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[bg  time="0"  method="fadeIn"  storage="sin_rin_sejyutusitu.png"  ]
[mask_off  time="1000"  effect="slideOutRight"  ]
*top

[tb_hide_message_window  ]
[tb_start_tyrano_code]
;変数0の場合カメラ配置場所を表記

;high
[if exp="f.com_massage_high == 0 "]
[call target="*com_1"]
[endif]

;tansu
[if exp="f.com_massage_tansu == 0 "]
[call target="*com_2"]
[endif]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
;変数1の場合配置済みを表記

[if exp="f.com_massage_high == 1 "]
[call target="*done_1"]
[endif]

[if exp="f.com_massage_tansu == 1 "]
[call target="*done_2"]

[endif]
[_tb_end_tyrano_code]

[call  storage="sinnyu_item.ks"  target="*turn_m"  ]
[call  storage="sinnyu_item.ks"  target="*com"  ]
[call  storage="sinnyu_item.ks"  target="*idoubutton_massaji_com"  ]
[s  ]
*com_1

[tb_start_tyrano_code]
;high
[layermode time="0" graphic="../fgimage/default/massage_high.gif" mode="screen"]

[_tb_end_tyrano_code]

[clickable  storage="sinnyu_comhaiti.ks"  x="357"  y="19"  width="130"  height="130"  target="*kakunin_massage_high"  _clickable_img=""  ]
[return  ]
*com_2

[tb_start_tyrano_code]
;low
[layermode time="0" graphic="../fgimage/default/massage_tansu.gif" mode="screen"]

[_tb_end_tyrano_code]

[clickable  storage="sinnyu_comhaiti.ks"  x="845"  y="297"  width="130"  height="130"  target="*kakunin_massage_tansu"  _clickable_img=""  ]
[return  ]
*done_1

[tb_start_tyrano_code]
[image layer="2" x=" 362" y=" -7" storage="default/done.png" time="0" ]
[_tb_end_tyrano_code]

[return  ]
*done_2

[tb_start_tyrano_code]
[image layer="2" x="876" y="303" storage="default/done.png" time="0" ]
[_tb_end_tyrano_code]

[return  ]
*com_1_setti

[jump  storage="sinnyu_massaji_haiti.ks"  target="*nasi"  cond="f.item_com==0"  ]
[call  storage="sinnyu_comhaiti.ks"  target="*setti"  ]
[tb_eval  exp="f.com_massage_high=1"  name="com_massage_high"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[jump  storage="sinnyu_massaji_haiti.ks"  target="*end"  ]
*com_2_setti

[jump  storage="sinnyu_massaji_haiti.ks"  target="*nasi"  cond="f.item_com==0"  ]
[call  storage="sinnyu_comhaiti.ks"  target="*setti"  ]
[tb_eval  exp="f.com_massage_tansu=1"  name="com_massage_tansu"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[jump  storage="sinnyu_massaji_haiti.ks"  target="*end"  ]
*setti_yameru

[tb_start_tyrano_code]
;エフェクト消す
[free_layermode time="500"]
[freeimage layer="2" time="500"]
[_tb_end_tyrano_code]

[call  storage="sinnyu_item.ks"  target="*turn_m"  ]
[call  storage="sinnyu_item.ks"  target="*com"  ]
[call  storage="sinnyu_item.ks"  target="*idoubutton_massaji_com"  ]
[jump  storage="sinnyu_massaji_haiti.ks"  target="*end"  ]
*nasi

[call  storage="sinnyu_comhaiti.ks"  target="*nasi"  ]
[jump  storage="sinnyu_massaji_haiti.ks"  target="*top"  ]
*end

[call  storage="sinnyu_item.ks"  target="*off"  ]
[call  storage="sinnyu_item.ks"  target="*com"  ]
[tb_start_tyrano_code]
;行動0で終了
[if exp="f.sinnyu_koudou_count == 0"]
[jump storage="sinnyu_nagi.ks" target="*end"]
[endif]

[jump target="*top"]
[_tb_end_tyrano_code]

[jump  storage="sinnyu_massaji_haiti.ks"  target="*top"  